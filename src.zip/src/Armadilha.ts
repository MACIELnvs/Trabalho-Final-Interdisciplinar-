import { Carta } from "../src/Carta";
import { Colecao } from "../src/Colecao";
import { IPesquisavel } from "./IPesquisavel";

export class Armadilha extends Carta implements IPesquisavel {

    private _tipoArmadilha: string;

    constructor(id: number, nome: string, img: string, descricao: string, vetColecao: Array<Colecao>, tipoArmadilha: string) {
        super(id, nome, img, descricao, vetColecao);

        this._tipoArmadilha = tipoArmadilha;
    }

    get tipoArmadilha(): string {
        return this._tipoArmadilha;
    }

    set tipoArmadilha(tipoArmadilha: string) {
        this._tipoArmadilha = tipoArmadilha;
    }

    atendeCriterio(tipoPesquisado: string): boolean {
        if (this._tipoArmadilha == tipoPesquisado) {
            return true;
        }
        return false;
    }

    toString(): string {
        return `Armadilha: ${super.toString()} - Tipo de Armadilha: ${this._tipoArmadilha}`;
    }


}